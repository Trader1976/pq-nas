document.getElementById("out").textContent = "Loaded OK: " + new Date().toISOString();
