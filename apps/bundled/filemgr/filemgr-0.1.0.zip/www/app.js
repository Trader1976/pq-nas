cat > /tmp/pqnas_filemgr/www/app.js <<'EOF'
(() => {
  const gridEl = document.getElementById("grid");
  const pathLine = document.getElementById("pathLine");
  const badge = document.getElementById("badge");
  const status = document.getElementById("status");
  const refreshBtn = document.getElementById("refreshBtn");
  const upBtn = document.getElementById("upBtn");

  let curPath = "";      // "" == root
  let selectedKey = "";  // "dir:test" or "file:hello.txt"

  function setBadge(kind, text){
    badge.className = `badge ${kind}`;
    badge.textContent = text;
  }

  function joinPath(base, name){
    if (!base) return name;
    return `${base}/${name}`;
  }

  function parentPath(p){
    if (!p) return "";
    const i = p.lastIndexOf("/");
    if (i < 0) return "";
    return p.slice(0, i);
  }

  function fmtSize(n){
    const u = ["B","KiB","MiB","GiB","TiB"];
    let v = Number(n || 0);
    let i = 0;
    while (v >= 1024 && i < u.length-1){ v /= 1024; i++; }
    return (i===0 ? `${v|0} ${u[i]}` : `${v.toFixed(1)} ${u[i]}`);
  }

  function fmtTime(unix){
    if (!unix) return "";
    const d = new Date(unix * 1000);
    return d.toISOString().replace("T"," ").replace("Z","");
  }

  function iconFor(item){
    if (item.type === "dir") return "./icons/folder.png";

    const n = String(item.name || "");
    const dot = n.lastIndexOf(".");
    const ext = (dot >= 0 ? n.slice(dot + 1) : "").toLowerCase();

    if (["txt","md","log","json","yaml","yml","ini","cfg","conf"].includes(ext)) return "./icons/text.png";
    if (["c","cc","cpp","cxx","h","hh","hpp","hxx"].includes(ext)) return "./icons/cpp.png";
    if (["html","htm","css","js","mjs","cjs","ts","tsx","jsx"].includes(ext)) return "./icons/html.png";
    if (["png","jpg","jpeg","gif","webp","bmp","svg","ico","tiff"].includes(ext)) return "./icons/image.png";
    if (["exe","bin","run","appimage","sh"].includes(ext)) return "./icons/exe.png";

    return "./icons/file.png";
  }

  function clear(){
    gridEl.innerHTML = "";
  }

  function setSelected(key){
    selectedKey = key;
    for (const el of gridEl.querySelectorAll(".tile")){
      el.classList.toggle("sel", el.dataset.key === key);
    }
  }

  function tile(item){
    const key = `${item.type}:${item.name}`;
    const t = document.createElement("div");
    t.className = "tile";
    t.dataset.key = key;

    const img = document.createElement("img");
    img.className = "ico";
    img.alt = "";
    img.src = iconFor(item);

    const nm = document.createElement("div");
    nm.className = "name";
    nm.textContent = item.name || "(unnamed)";

    const meta = document.createElement("div");
    meta.className = "meta";

    const left = document.createElement("span");
    left.textContent = (item.type === "dir") ? "dir" : fmtSize(item.size_bytes || 0);

    const right = document.createElement("span");
    right.textContent = fmtTime(item.mtime_unix);

    meta.appendChild(left);
    meta.appendChild(right);

    t.appendChild(img);
    t.appendChild(nm);
    t.appendChild(meta);

    // single click = select
    t.addEventListener("click", () => setSelected(key));

    // double click = open
    t.addEventListener("dblclick", () => {
      if (item.type === "dir") {
        curPath = joinPath(curPath, item.name);
        selectedKey = "";
        load();
      } else if (item.type === "file") {
        const p = joinPath(curPath, item.name);
        window.location.href = `/api/v4/files/get?path=${encodeURIComponent(p)}`;
      }
    });

    return t;
  }

  async function load(){
    setBadge("warn", "loading…");
    status.textContent = "Loading…";
    clear();

    try {
      const url = curPath ? `/api/v4/files/list?path=${encodeURIComponent(curPath)}` : `/api/v4/files/list`;
      const r = await fetch(url, { credentials: "include", cache: "no-store" });
      const j = await r.json().catch(() => null);

      if (!r.ok || !j || !j.ok) {
        setBadge("err", "error");
        status.textContent = `List failed: HTTP ${r.status}`;
        const msg = (j && (j.message || j.error)) ? `${j.error || ""} ${j.message || ""}`.trim() : "bad response";
        const err = document.createElement("div");
        err.className = "tile mono";
        err.style.cursor = "default";
        err.textContent = msg;
        gridEl.appendChild(err);
        return;
      }

      curPath = (typeof j.path === "string") ? j.path : curPath;
      pathLine.textContent = `path: ${curPath ? "/" + curPath : "/"}`;

      setBadge("ok", "ready");

      const items = Array.isArray(j.items) ? j.items.slice() : [];
      items.sort((a,b) => {
        if (a.type !== b.type) return (a.type === "dir") ? -1 : 1;
        return String(a.name||"").localeCompare(String(b.name||""));
      });

      status.textContent = `Items: ${items.length}`;

      if (!items.length) {
        const empty = document.createElement("div");
        empty.className = "tile mono";
        empty.style.cursor = "default";
        empty.textContent = "(empty)";
        gridEl.appendChild(empty);
        return;
      }

      for (const it of items) gridEl.appendChild(tile(it));

      if (selectedKey) setSelected(selectedKey);
    } catch (e) {
      setBadge("err", "network");
      status.textContent = "Network error";
      const err = document.createElement("div");
      err.className = "tile mono";
      err.style.cursor = "default";
      err.textContent = String(e && e.stack ? e.stack : e);
      gridEl.appendChild(err);
    }
  }

  refreshBtn?.addEventListener("click", load);
  upBtn?.addEventListener("click", () => {
    curPath = parentPath(curPath);
    selectedKey = "";
    load();
  });

  load();
})();


