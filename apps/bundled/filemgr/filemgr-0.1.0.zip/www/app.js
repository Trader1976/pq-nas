(() => {
  const listEl = document.getElementById("list");
  const pathLine = document.getElementById("pathLine");
  const badge = document.getElementById("badge");
  const status = document.getElementById("status");
  const refreshBtn = document.getElementById("refreshBtn");
  const upBtn = document.getElementById("upBtn");

  let curPath = ""; // "" == root in your API

  function setBadge(kind, text){
    badge.className = `badge ${kind}`;
    badge.textContent = text;
  }

  function fmtSize(n){
    if (n == null) return "";
    const u = ["B","KiB","MiB","GiB","TiB"];
    let v = Number(n);
    let i = 0;
    while (v >= 1024 && i < u.length-1){ v /= 1024; i++; }
    return (i===0 ? `${v|0} ${u[i]}` : `${v.toFixed(1)} ${u[i]}`);
  }

  function fmtTime(unix){
    if (!unix) return "";
    const d = new Date(unix * 1000);
    return d.toISOString().replace("T"," ").replace("Z","");
  }

  function joinPath(base, name){
    if (!base) return name;
    return `${base}/${name}`;
  }

  function parentPath(p){
    if (!p) return "";
    const i = p.lastIndexOf("/");
    if (i < 0) return "";
    return p.slice(0, i);
  }

  function clear(){
    listEl.innerHTML = "";
  }

  function row(item){
    const r = document.createElement("div");
    r.className = "row";

    const name = document.createElement("div");
    name.className = "name";
    name.textContent = item.name || "(unnamed)";

    const type = document.createElement("div");
    type.className = "meta colType";
    type.textContent = item.type || "";

    const size = document.createElement("div");
    size.className = "meta colSize";
    size.style.textAlign = "right";
    size.textContent = item.type === "file" ? fmtSize(item.size_bytes || 0) : "";

    const time = document.createElement("div");
    time.className = "meta colTime";
    time.style.textAlign = "right";
    time.textContent = fmtTime(item.mtime_unix);

    r.appendChild(name);
    r.appendChild(type);
    r.appendChild(size);
    r.appendChild(time);

    r.addEventListener("click", () => {
      if (item.type === "dir") {
        curPath = joinPath(curPath, item.name);
        load();
      } else if (item.type === "file") {
        // Download file. Adjust if your GET endpoint differs.
        const p = joinPath(curPath, item.name);
        const url = `/api/v4/files/get?path=${encodeURIComponent(p)}`;
        window.location.href = url;
      }
    });

    return r;
  }

  async function load(){
    setBadge("warn", "loading…");
    status.textContent = "Loading…";
    clear();

    try {
      // If later you add ?path=, switch to: `/api/v4/files/list?path=${encodeURIComponent(curPath)}`
      // For now, we keep your current API call and pass path via query if supported.
      const url = curPath ? `/api/v4/files/list?path=${encodeURIComponent(curPath)}` : `/api/v4/files/list`;
      const r = await fetch(url, { credentials: "include", cache: "no-store" });
      const j = await r.json().catch(() => null);

      if (!r.ok || !j || !j.ok) {
        setBadge("err", "error");
        status.textContent = `List failed: HTTP ${r.status}`;
        const msg = (j && (j.message || j.error)) ? `${j.error || ""} ${j.message || ""}`.trim() : "bad response";
        const pre = document.createElement("div");
        pre.className = "row mono";
        pre.style.cursor = "default";
        pre.textContent = msg;
        listEl.appendChild(pre);
        return;
      }

      // Server returns current path as j.path ("" at root)
      curPath = (typeof j.path === "string") ? j.path : curPath;
      pathLine.textContent = `path: ${curPath || "/"}`;

      setBadge("ok", "ready");
      status.textContent = `Items: ${(j.items || []).length}`;

      // Sort: dirs first, then files, then name
      const items = Array.isArray(j.items) ? j.items.slice() : [];
      items.sort((a,b) => {
        const ta = a.type || "";
        const tb = b.type || "";
        if (ta !== tb) return ta === "dir" ? -1 : 1;
        return String(a.name||"").localeCompare(String(b.name||""));
      });

      if (!items.length) {
        const empty = document.createElement("div");
        empty.className = "row mono";
        empty.style.cursor = "default";
        empty.textContent = "(empty)";
        listEl.appendChild(empty);
        return;
      }

      for (const it of items) listEl.appendChild(row(it));
    } catch (e) {
      setBadge("err", "network");
      status.textContent = "Network error";
      const pre = document.createElement("div");
      pre.className = "row mono";
      pre.style.cursor = "default";
      pre.textContent = String(e && e.stack ? e.stack : e);
      listEl.appendChild(pre);
    }
  }

  refreshBtn?.addEventListener("click", load);
  upBtn?.addEventListener("click", () => {
    curPath = parentPath(curPath);
    load();
  });

  load();
})();
